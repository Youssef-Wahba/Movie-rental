﻿namespace Movie_App
{
    partial class Newfilm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.Label newFilme;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Newfilm));
            this.backBtn = new System.Windows.Forms.Button();
            this.title = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.filmTitle = new System.Windows.Forms.Label();
            this.adminId = new System.Windows.Forms.Label();
            this.filmDesc = new System.Windows.Forms.Label();
            this.filmLang = new System.Windows.Forms.Label();
            this.filmRating = new System.Windows.Forms.Label();
            this.filmReleaseDate = new System.Windows.Forms.Label();
            this.filmPrice = new System.Windows.Forms.Label();
            this.AddFilm = new System.Windows.Forms.Button();
            newFilme = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // newFilme
            // 
            newFilme.AutoSize = true;
            newFilme.Font = new System.Drawing.Font("Showcard Gothic", 28.2F, System.Drawing.FontStyle.Bold);
            newFilme.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            newFilme.Location = new System.Drawing.Point(369, 9);
            newFilme.Name = "newFilme";
            newFilme.Size = new System.Drawing.Size(255, 59);
            newFilme.TabIndex = 15;
            newFilme.Text = "New Film";
            // 
            // backBtn
            // 
            this.backBtn.BackColor = System.Drawing.Color.Black;
            this.backBtn.Font = new System.Drawing.Font("Showcard Gothic", 7.8F, System.Drawing.FontStyle.Italic);
            this.backBtn.ForeColor = System.Drawing.Color.White;
            this.backBtn.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.backBtn.Location = new System.Drawing.Point(865, 463);
            this.backBtn.Name = "backBtn";
            this.backBtn.Size = new System.Drawing.Size(73, 44);
            this.backBtn.TabIndex = 13;
            this.backBtn.Text = "back";
            this.backBtn.UseVisualStyleBackColor = false;
            this.backBtn.Click += new System.EventHandler(this.backBtn_Click);
            // 
            // title
            // 
            this.title.AutoSize = true;
            this.title.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.title.Cursor = System.Windows.Forms.Cursors.Default;
            this.title.Font = new System.Drawing.Font("Showcard Gothic", 10.2F);
            this.title.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.title.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.title.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.title.Location = new System.Drawing.Point(12, 9);
            this.title.Name = "title";
            this.title.Size = new System.Drawing.Size(127, 21);
            this.title.TabIndex = 14;
            this.title.Text = "Movie Rental";
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(12, 457);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(847, 72);
            this.dataGridView1.TabIndex = 16;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(327, 111);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(366, 22);
            this.textBox1.TabIndex = 17;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(327, 157);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(366, 22);
            this.textBox2.TabIndex = 18;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(327, 201);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(366, 22);
            this.textBox3.TabIndex = 19;
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(327, 254);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(366, 22);
            this.textBox4.TabIndex = 20;
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(327, 309);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(366, 22);
            this.textBox5.TabIndex = 21;
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(327, 362);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(366, 22);
            this.textBox6.TabIndex = 22;
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(327, 407);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(366, 22);
            this.textBox7.TabIndex = 23;
            // 
            // filmTitle
            // 
            this.filmTitle.AutoSize = true;
            this.filmTitle.Font = new System.Drawing.Font("Showcard Gothic", 10.2F);
            this.filmTitle.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.filmTitle.Location = new System.Drawing.Point(134, 155);
            this.filmTitle.Name = "filmTitle";
            this.filmTitle.Size = new System.Drawing.Size(54, 21);
            this.filmTitle.TabIndex = 24;
            this.filmTitle.Text = "Title";
            // 
            // adminId
            // 
            this.adminId.AutoSize = true;
            this.adminId.Font = new System.Drawing.Font("Showcard Gothic", 10.2F);
            this.adminId.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.adminId.Location = new System.Drawing.Point(134, 109);
            this.adminId.Name = "adminId";
            this.adminId.Size = new System.Drawing.Size(87, 21);
            this.adminId.TabIndex = 24;
            this.adminId.Text = "Admin ID";
            // 
            // filmDesc
            // 
            this.filmDesc.AutoSize = true;
            this.filmDesc.Font = new System.Drawing.Font("Showcard Gothic", 10.2F);
            this.filmDesc.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.filmDesc.Location = new System.Drawing.Point(134, 202);
            this.filmDesc.Name = "filmDesc";
            this.filmDesc.Size = new System.Drawing.Size(51, 21);
            this.filmDesc.TabIndex = 25;
            this.filmDesc.Text = "desc";
            // 
            // filmLang
            // 
            this.filmLang.AutoSize = true;
            this.filmLang.Font = new System.Drawing.Font("Showcard Gothic", 10.2F);
            this.filmLang.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.filmLang.Location = new System.Drawing.Point(134, 252);
            this.filmLang.Name = "filmLang";
            this.filmLang.Size = new System.Drawing.Size(52, 21);
            this.filmLang.TabIndex = 26;
            this.filmLang.Text = "lang";
            // 
            // filmRating
            // 
            this.filmRating.AutoSize = true;
            this.filmRating.Font = new System.Drawing.Font("Showcard Gothic", 10.2F);
            this.filmRating.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.filmRating.Location = new System.Drawing.Point(134, 307);
            this.filmRating.Name = "filmRating";
            this.filmRating.Size = new System.Drawing.Size(71, 21);
            this.filmRating.TabIndex = 27;
            this.filmRating.Text = "Rating";
            // 
            // filmReleaseDate
            // 
            this.filmReleaseDate.AutoSize = true;
            this.filmReleaseDate.Font = new System.Drawing.Font("Showcard Gothic", 10.2F);
            this.filmReleaseDate.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.filmReleaseDate.Location = new System.Drawing.Point(115, 363);
            this.filmReleaseDate.Name = "filmReleaseDate";
            this.filmReleaseDate.Size = new System.Drawing.Size(190, 21);
            this.filmReleaseDate.TabIndex = 28;
            this.filmReleaseDate.Text = "ReleaseDate (y-m-d)";
            // 
            // filmPrice
            // 
            this.filmPrice.AutoSize = true;
            this.filmPrice.Font = new System.Drawing.Font("Showcard Gothic", 10.2F);
            this.filmPrice.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.filmPrice.Location = new System.Drawing.Point(134, 405);
            this.filmPrice.Name = "filmPrice";
            this.filmPrice.Size = new System.Drawing.Size(58, 21);
            this.filmPrice.TabIndex = 29;
            this.filmPrice.Text = "Price";
            // 
            // AddFilm
            // 
            this.AddFilm.BackColor = System.Drawing.Color.Black;
            this.AddFilm.Font = new System.Drawing.Font("Showcard Gothic", 7.8F, System.Drawing.FontStyle.Italic);
            this.AddFilm.ForeColor = System.Drawing.Color.White;
            this.AddFilm.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.AddFilm.Location = new System.Drawing.Point(763, 242);
            this.AddFilm.Name = "AddFilm";
            this.AddFilm.Size = new System.Drawing.Size(122, 44);
            this.AddFilm.TabIndex = 30;
            this.AddFilm.Text = "Add";
            this.AddFilm.UseVisualStyleBackColor = false;
            this.AddFilm.Click += new System.EventHandler(this.AddFilm_Click);
            // 
            // Newfilm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(950, 541);
            this.Controls.Add(this.AddFilm);
            this.Controls.Add(this.filmPrice);
            this.Controls.Add(this.filmReleaseDate);
            this.Controls.Add(this.filmRating);
            this.Controls.Add(this.filmLang);
            this.Controls.Add(this.filmDesc);
            this.Controls.Add(this.adminId);
            this.Controls.Add(this.filmTitle);
            this.Controls.Add(this.textBox7);
            this.Controls.Add(this.textBox6);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(newFilme);
            this.Controls.Add(this.title);
            this.Controls.Add(this.backBtn);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Newfilm";
            this.Text = "New Film";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button backBtn;
        private System.Windows.Forms.Label title;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.Label filmTitle;
        private System.Windows.Forms.Label adminId;
        private System.Windows.Forms.Label filmDesc;
        private System.Windows.Forms.Label filmLang;
        private System.Windows.Forms.Label filmRating;
        private System.Windows.Forms.Label filmReleaseDate;
        private System.Windows.Forms.Label filmPrice;
        private System.Windows.Forms.Button AddFilm;
    }
}