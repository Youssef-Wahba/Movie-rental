﻿namespace Movie_App
{
    partial class LogInForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.Label login;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(LogInForm));
            this.title = new System.Windows.Forms.Label();
            this.loginId = new System.Windows.Forms.Label();
            this.PassLabel = new System.Windows.Forms.Label();
            this.IDtextBox = new System.Windows.Forms.TextBox();
            this.passTextBox = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.Userbtn = new System.Windows.Forms.Button();
            this.backBtn = new System.Windows.Forms.Button();
            login = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // login
            // 
            resources.ApplyResources(login, "login");
            login.Name = "login";
            // 
            // title
            // 
            resources.ApplyResources(this.title, "title");
            this.title.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.title.Cursor = System.Windows.Forms.Cursors.Default;
            this.title.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.title.Name = "title";
            this.title.Click += new System.EventHandler(this.label1_Click);
            // 
            // loginId
            // 
            resources.ApplyResources(this.loginId, "loginId");
            this.loginId.Name = "loginId";
            this.loginId.Click += new System.EventHandler(this.label1_Click_1);
            // 
            // PassLabel
            // 
            resources.ApplyResources(this.PassLabel, "PassLabel");
            this.PassLabel.Name = "PassLabel";
            // 
            // IDtextBox
            // 
            resources.ApplyResources(this.IDtextBox, "IDtextBox");
            this.IDtextBox.Name = "IDtextBox";
            this.IDtextBox.TextChanged += new System.EventHandler(this.IDtextBox_TextChanged);
            // 
            // passTextBox
            // 
            resources.ApplyResources(this.passTextBox, "passTextBox");
            this.passTextBox.Name = "passTextBox";
            // 
            // button1
            // 
            resources.ApplyResources(this.button1, "button1");
            this.button1.BackColor = System.Drawing.Color.Black;
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Name = "button1";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Userbtn
            // 
            resources.ApplyResources(this.Userbtn, "Userbtn");
            this.Userbtn.BackColor = System.Drawing.Color.Black;
            this.Userbtn.ForeColor = System.Drawing.Color.White;
            this.Userbtn.Name = "Userbtn";
            this.Userbtn.UseVisualStyleBackColor = false;
            this.Userbtn.Click += new System.EventHandler(this.Userbtn_Click);
            // 
            // backBtn
            // 
            resources.ApplyResources(this.backBtn, "backBtn");
            this.backBtn.BackColor = System.Drawing.Color.Black;
            this.backBtn.ForeColor = System.Drawing.Color.White;
            this.backBtn.Name = "backBtn";
            this.backBtn.UseVisualStyleBackColor = false;
            this.backBtn.Click += new System.EventHandler(this.backBtn_Click);
            // 
            // LogInForm
            // 
            resources.ApplyResources(this, "$this");
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.Controls.Add(this.backBtn);
            this.Controls.Add(this.Userbtn);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.passTextBox);
            this.Controls.Add(this.IDtextBox);
            this.Controls.Add(this.PassLabel);
            this.Controls.Add(this.loginId);
            this.Controls.Add(login);
            this.Controls.Add(this.title);
            this.Name = "LogInForm";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label title;
        private System.Windows.Forms.Label loginId;
        private System.Windows.Forms.Label PassLabel;
        private System.Windows.Forms.TextBox IDtextBox;
        private System.Windows.Forms.TextBox passTextBox;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button Userbtn;
        private System.Windows.Forms.Button backBtn;
    }
}

