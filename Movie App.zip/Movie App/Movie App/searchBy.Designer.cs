﻿namespace Movie_App
{
    partial class searchBy
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(searchBy));
            this.title = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.searchCriteia = new System.Windows.Forms.TextBox();
            this.fimNameDataGridView = new System.Windows.Forms.DataGridView();
            this.searchByNameBtn = new System.Windows.Forms.Button();
            this.backBtn = new System.Windows.Forms.Button();
            this.searchByLangugeBtn = new System.Windows.Forms.Button();
            this.searchByRatingBtn = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.fimNameDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // title
            // 
            this.title.AutoSize = true;
            this.title.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.title.Cursor = System.Windows.Forms.Cursors.Default;
            this.title.Font = new System.Drawing.Font("Showcard Gothic", 10.2F);
            this.title.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.title.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.title.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.title.Location = new System.Drawing.Point(12, 9);
            this.title.Name = "title";
            this.title.Size = new System.Drawing.Size(127, 21);
            this.title.TabIndex = 2;
            this.title.Text = "Movie Rental";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Cursor = System.Windows.Forms.Cursors.Default;
            this.label1.Font = new System.Drawing.Font("Showcard Gothic", 10.2F);
            this.label1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label1.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.label1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label1.Location = new System.Drawing.Point(68, 102);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(73, 21);
            this.label1.TabIndex = 3;
            this.label1.Text = "Search";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(455, 138);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(8, 8);
            this.button1.TabIndex = 4;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // searchCriteia
            // 
            this.searchCriteia.Location = new System.Drawing.Point(234, 101);
            this.searchCriteia.Name = "searchCriteia";
            this.searchCriteia.Size = new System.Drawing.Size(425, 22);
            this.searchCriteia.TabIndex = 17;
            this.searchCriteia.TextChanged += new System.EventHandler(this.signupFirstName_TextChanged);
            // 
            // fimNameDataGridView
            // 
            this.fimNameDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.fimNameDataGridView.Location = new System.Drawing.Point(16, 212);
            this.fimNameDataGridView.Name = "fimNameDataGridView";
            this.fimNameDataGridView.RowHeadersWidth = 51;
            this.fimNameDataGridView.RowTemplate.Height = 24;
            this.fimNameDataGridView.Size = new System.Drawing.Size(772, 209);
            this.fimNameDataGridView.TabIndex = 18;
            // 
            // searchByNameBtn
            // 
            this.searchByNameBtn.BackColor = System.Drawing.Color.Black;
            this.searchByNameBtn.Font = new System.Drawing.Font("Showcard Gothic", 7.8F, System.Drawing.FontStyle.Italic);
            this.searchByNameBtn.ForeColor = System.Drawing.Color.White;
            this.searchByNameBtn.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.searchByNameBtn.Location = new System.Drawing.Point(234, 150);
            this.searchByNameBtn.Name = "searchByNameBtn";
            this.searchByNameBtn.Size = new System.Drawing.Size(122, 44);
            this.searchByNameBtn.TabIndex = 19;
            this.searchByNameBtn.Text = "Name";
            this.searchByNameBtn.UseVisualStyleBackColor = false;
            this.searchByNameBtn.Click += new System.EventHandler(this.searchByNameBtn_Click);
            // 
            // backBtn
            // 
            this.backBtn.BackColor = System.Drawing.Color.Black;
            this.backBtn.Font = new System.Drawing.Font("Showcard Gothic", 7.8F, System.Drawing.FontStyle.Italic);
            this.backBtn.ForeColor = System.Drawing.Color.White;
            this.backBtn.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.backBtn.Location = new System.Drawing.Point(715, 435);
            this.backBtn.Name = "backBtn";
            this.backBtn.Size = new System.Drawing.Size(73, 44);
            this.backBtn.TabIndex = 20;
            this.backBtn.Text = "back";
            this.backBtn.UseVisualStyleBackColor = false;
            this.backBtn.Click += new System.EventHandler(this.backBtn_Click);
            // 
            // searchByLangugeBtn
            // 
            this.searchByLangugeBtn.BackColor = System.Drawing.Color.Black;
            this.searchByLangugeBtn.Font = new System.Drawing.Font("Showcard Gothic", 7.8F, System.Drawing.FontStyle.Italic);
            this.searchByLangugeBtn.ForeColor = System.Drawing.Color.White;
            this.searchByLangugeBtn.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.searchByLangugeBtn.Location = new System.Drawing.Point(384, 150);
            this.searchByLangugeBtn.Name = "searchByLangugeBtn";
            this.searchByLangugeBtn.Size = new System.Drawing.Size(122, 44);
            this.searchByLangugeBtn.TabIndex = 21;
            this.searchByLangugeBtn.Text = "Language";
            this.searchByLangugeBtn.UseVisualStyleBackColor = false;
            this.searchByLangugeBtn.Click += new System.EventHandler(this.searchByLangugeBtn_Click);
            // 
            // searchByRatingBtn
            // 
            this.searchByRatingBtn.BackColor = System.Drawing.Color.Black;
            this.searchByRatingBtn.Font = new System.Drawing.Font("Showcard Gothic", 7.8F, System.Drawing.FontStyle.Italic);
            this.searchByRatingBtn.ForeColor = System.Drawing.Color.White;
            this.searchByRatingBtn.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.searchByRatingBtn.Location = new System.Drawing.Point(537, 150);
            this.searchByRatingBtn.Name = "searchByRatingBtn";
            this.searchByRatingBtn.Size = new System.Drawing.Size(122, 44);
            this.searchByRatingBtn.TabIndex = 22;
            this.searchByRatingBtn.Text = "Rating";
            this.searchByRatingBtn.UseVisualStyleBackColor = false;
            this.searchByRatingBtn.Click += new System.EventHandler(this.searchByRatingBtn_Click);
            // 
            // searchBy
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(806, 491);
            this.Controls.Add(this.searchByRatingBtn);
            this.Controls.Add(this.searchByLangugeBtn);
            this.Controls.Add(this.backBtn);
            this.Controls.Add(this.searchByNameBtn);
            this.Controls.Add(this.fimNameDataGridView);
            this.Controls.Add(this.searchCriteia);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.title);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "searchBy";
            this.Text = "Search By";
            ((System.ComponentModel.ISupportInitialize)(this.fimNameDataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label title;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox searchCriteia;
        private System.Windows.Forms.DataGridView fimNameDataGridView;
        private System.Windows.Forms.Button searchByNameBtn;
        private System.Windows.Forms.Button backBtn;
        private System.Windows.Forms.Button searchByLangugeBtn;
        private System.Windows.Forms.Button searchByRatingBtn;
    }
}