﻿using System;
using System.Windows.Forms;

namespace Movie_App
{
    public partial class firstForm : Form
    {
        public firstForm()
        {
            InitializeComponent();
        }

        private void signUpBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            signUpForm sign = new signUpForm();
            sign.Show();
        }

        private void logInBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            LogInForm log = new LogInForm();
            log.Show();
        }
    }
}
