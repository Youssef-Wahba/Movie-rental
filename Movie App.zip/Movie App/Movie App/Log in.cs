﻿using System;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Movie_App
{

    public partial class LogInForm : Form
    {

        public LogInForm()
        {
            InitializeComponent();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void toolTip1_Popup(object sender, PopupEventArgs e)
        {

        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void IDtextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void emailTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void backBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            firstForm first = new firstForm();
            first.Show();
        }

        private void Userbtn_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=JOE-LABTOP;Initial Catalog=MovieAppDB;Integrated Security=True");
            SqlCommand comnew = new SqlCommand("SELECT PASSWORD FROM CUSTOMER WHERE CID = " + IDtextBox.Text, con);
            con.Open();
            comnew.ExecuteNonQuery();
            string pass = (string)comnew.ExecuteScalar();
            if(pass== passTextBox.Text)
            {
                this.Hide();
                userPage userpage = new userPage();
                userpage.Show();
            }
            else
            {
                MessageBox.Show("ID Or Password Not Valid");
            }

            con.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=JOE-LABTOP;Initial Catalog=MovieAppDB;Integrated Security=True");
            SqlCommand comnew = new SqlCommand("SELECT PASSWORD FROM ADMIN WHERE ADID = " + IDtextBox.Text, con);
            con.Open();
            comnew.ExecuteNonQuery();

            string pass = (string)comnew.ExecuteScalar();
            if (pass == passTextBox.Text)
            {
                this.Hide();
                adminPage adminpage = new adminPage();  
                adminpage.Show();
            }
            else
            {
                MessageBox.Show("ID Or Password Incorrect");
            }
            con.Close();
        }
    }
    
}
