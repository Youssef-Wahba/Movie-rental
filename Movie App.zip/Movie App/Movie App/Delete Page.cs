﻿using System;
using System.Data;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Movie_App
{
    public partial class deleteupdateForm : Form
    {
        public deleteupdateForm()
        {
            InitializeComponent();
        }

        private void deleteupdateForm_Load(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=JOE-LABTOP;Initial Catalog=MovieAppDB;Integrated Security=True");
            con.Open();
            SqlDataAdapter dataAdapter = new SqlDataAdapter("SELECT * FROM MOVIE ", con);
            DataTable dataTable = new DataTable();
            dataAdapter.Fill(dataTable);
            dataGridView1.DataSource = dataTable;
            dataGridView1.AutoResizeColumns();
            con.Close();
        }

        private void deleteFilm_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=JOE-LABTOP;Initial Catalog=MovieAppDB;Integrated Security=True");
            SqlCommand comnew = new SqlCommand("DELETE FROM MOVIE WHERE MID = " + textBox1.Text + "", con);
            con.Open();
            comnew.ExecuteNonQuery();
            SqlDataAdapter dataAdapter = new SqlDataAdapter("SELECT * FROM MOVIE ", con);
            DataTable dataTable = new DataTable();
            dataAdapter.Fill(dataTable);
            dataGridView1.DataSource = dataTable;
            dataGridView1.AutoResizeColumns();
            con.Close();
        }

        private void backBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            adminPage adminPage = new adminPage();
            adminPage.Show();
        }
    }
}
