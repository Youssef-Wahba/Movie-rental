﻿using System;
using System.Data;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Movie_App
{
    public partial class Newfilm : Form
    {
        public Newfilm()
        {
            InitializeComponent();
        }

        private void backBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            adminPage adminPage = new adminPage();  
            adminPage.Show();

        }

        private void AddFilm_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=JOE-LABTOP;Initial Catalog=MovieAppDB;Integrated Security=True");
            SqlCommand comnew = new SqlCommand("INSERT INTO MOVIE VALUES("+textBox1.Text+",'"+ textBox2.Text+"','"+ textBox3.Text+"','"+ textBox4.Text+"','"+ textBox5.Text+"','"+ textBox6.Text+"',"+ textBox7.Text+")", con);
            con.Open();
            comnew.ExecuteNonQuery();
            SqlDataAdapter dataAdapter = new SqlDataAdapter("SELECT * FROM MOVIE WHERE MID = (SELECT MAX(MID) FROM MOVIE)", con);
            DataTable dataTable = new DataTable();
            dataAdapter.Fill(dataTable);
            dataGridView1.DataSource = dataTable;
            dataGridView1.AutoResizeColumns();
            MessageBox.Show("Success :)");
            con.Close();
        }
    }
}
