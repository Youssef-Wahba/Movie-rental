﻿using System;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Movie_App
{
    public partial class signUpForm : Form
    {
        public signUpForm()
        {
            InitializeComponent();     
        }
        private void login_Click(object sender, EventArgs e)
        {

        }

        private void Userbtn_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=JOE-LABTOP;Initial Catalog=MovieAppDB;Integrated Security=True");
            SqlCommand comnew = new SqlCommand("INSERT INTO CUSTOMER VALUES('" + signupFirstName.Text + "','" + lastNameTextBox.Text + "','" + addressTextBox.Text + "','" + phoneNumberTextBox.Text + "','" + emailTextBox.Text + "','" + textBox6.Text + "')",con);
            con.Open();
            comnew.ExecuteNonQuery();
            SqlCommand comnew2 = new SqlCommand("SELECT MAX(CID) FROM CUSTOMER", con);
            int id = (int)comnew2.ExecuteScalar();
            MessageBox.Show("ID : " + id + "\nUser Signed Up Successfully :)");
            con.Close();
        }

        private void IDtextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void backBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            firstForm first = new firstForm();
            first.Show();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=JOE-LABTOP;Initial Catalog=MovieAppDB;Integrated Security=True");
            SqlCommand comnew = new SqlCommand("INSERT INTO ADMIN VALUES('" + signupFirstName.Text + "','" + lastNameTextBox.Text + "','" + addressTextBox.Text + "','" + phoneNumberTextBox.Text + "','" + emailTextBox.Text + "','" + textBox6.Text + "')", con);
            con.Open();
            comnew.ExecuteNonQuery();
            SqlCommand comnew2 = new SqlCommand("SELECT MAX(ADID) FROM ADMIN", con);
            int id = (int)comnew2.ExecuteScalar();
            MessageBox.Show("ID : " + id + "\nAdmin Signed Up Successfully :)");
            con.Close();
        }
    }
}
