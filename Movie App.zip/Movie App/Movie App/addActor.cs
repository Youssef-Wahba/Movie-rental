﻿using System;
using System.Data;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace Movie_App
{
    public partial class addActor : Form
    {
        public addActor()
        {
            InitializeComponent();
        }

        private void backBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            adminPage adminPage = new adminPage();
            adminPage.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=JOE-LABTOP;Initial Catalog=MovieAppDB;Integrated Security=True");
            SqlCommand comnew = new SqlCommand("INSERT INTO ACTOR VALUES('" + textBox2.Text + "')", con);
            SqlCommand comnew2 = new SqlCommand("SELECT MAX(AID) FROM ACTOR", con);
            con.Open();
            comnew.ExecuteNonQuery();
            int id = (int)comnew2.ExecuteScalar();
            SqlCommand comnew3 = new SqlCommand("INSERT INTO ACTS_IN VALUES( "+ id +" , " + textBox1.Text + ",'"+ textBox3.Text + "' )", con);
            comnew3.ExecuteNonQuery();
            SqlDataAdapter dataAdapter = new SqlDataAdapter("SELECT ACTOR.AID,ACTOR.NAME FROM ACTOR INNER JOIN  ACTS_IN ON ACTOR.AID = ACTS_IN.AID AND ACTS_IN.MID = " + textBox1.Text + " ", con);
            DataTable dataTable = new DataTable();
            dataAdapter.Fill(dataTable);
            dataGridView2.DataSource = dataTable;
            dataGridView2.AutoResizeColumns();
            con.Close();
        }

        private void addActor_Load(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=JOE-LABTOP;Initial Catalog=MovieAppDB;Integrated Security=True");
            con.Open();
            SqlDataAdapter dataAdapter = new SqlDataAdapter("SELECT * FROM MOVIE", con);
            DataTable dataTable = new DataTable();
            dataAdapter.Fill(dataTable);
            dataGridView1.DataSource = dataTable;
            dataGridView1.AutoResizeColumns();
            con.Close();
        }
    }
}
