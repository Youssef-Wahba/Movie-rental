﻿namespace Movie_App
{
    partial class userPage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(userPage));
            this.searchBtn = new System.Windows.Forms.Button();
            this.title = new System.Windows.Forms.Label();
            this.backBtn = new System.Windows.Forms.Button();
            this.udateBtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // searchBtn
            // 
            this.searchBtn.BackColor = System.Drawing.Color.Black;
            this.searchBtn.Font = new System.Drawing.Font("Showcard Gothic", 25.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.searchBtn.ForeColor = System.Drawing.Color.White;
            this.searchBtn.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.searchBtn.Location = new System.Drawing.Point(75, 135);
            this.searchBtn.Name = "searchBtn";
            this.searchBtn.Size = new System.Drawing.Size(252, 118);
            this.searchBtn.TabIndex = 10;
            this.searchBtn.Text = "Film Search";
            this.searchBtn.UseVisualStyleBackColor = false;
            this.searchBtn.Click += new System.EventHandler(this.searchBtn_Click);
            // 
            // title
            // 
            this.title.AutoSize = true;
            this.title.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.title.Cursor = System.Windows.Forms.Cursors.Default;
            this.title.Font = new System.Drawing.Font("Showcard Gothic", 10.2F);
            this.title.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.title.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.title.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.title.Location = new System.Drawing.Point(12, 9);
            this.title.Name = "title";
            this.title.Size = new System.Drawing.Size(127, 21);
            this.title.TabIndex = 11;
            this.title.Text = "Movie Rental";
            // 
            // backBtn
            // 
            this.backBtn.BackColor = System.Drawing.Color.Black;
            this.backBtn.Font = new System.Drawing.Font("Showcard Gothic", 7.8F, System.Drawing.FontStyle.Italic);
            this.backBtn.ForeColor = System.Drawing.Color.White;
            this.backBtn.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.backBtn.Location = new System.Drawing.Point(715, 394);
            this.backBtn.Name = "backBtn";
            this.backBtn.Size = new System.Drawing.Size(73, 44);
            this.backBtn.TabIndex = 12;
            this.backBtn.Text = "back";
            this.backBtn.UseVisualStyleBackColor = false;
            this.backBtn.Click += new System.EventHandler(this.backBtn_Click);
            // 
            // udateBtn
            // 
            this.udateBtn.BackColor = System.Drawing.Color.Black;
            this.udateBtn.Font = new System.Drawing.Font("Showcard Gothic", 25.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.udateBtn.ForeColor = System.Drawing.Color.White;
            this.udateBtn.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.udateBtn.Location = new System.Drawing.Point(436, 135);
            this.udateBtn.Name = "udateBtn";
            this.udateBtn.Size = new System.Drawing.Size(254, 118);
            this.udateBtn.TabIndex = 13;
            this.udateBtn.Text = "Update Account";
            this.udateBtn.UseVisualStyleBackColor = false;
            this.udateBtn.Click += new System.EventHandler(this.udateBtn_Click);
            // 
            // userPage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.udateBtn);
            this.Controls.Add(this.backBtn);
            this.Controls.Add(this.title);
            this.Controls.Add(this.searchBtn);
            this.ForeColor = System.Drawing.SystemColors.ControlText;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "userPage";
            this.Text = "User Page";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button searchBtn;
        private System.Windows.Forms.Label title;
        private System.Windows.Forms.Button backBtn;
        private System.Windows.Forms.Button udateBtn;
    }
}