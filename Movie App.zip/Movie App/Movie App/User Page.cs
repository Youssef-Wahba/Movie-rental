﻿using System;
using System.Windows.Forms;

namespace Movie_App
{
    public partial class userPage : Form
    {
        public userPage()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void backBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            LogInForm login=new LogInForm();
            login.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void udateBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            updateForm updateForm = new updateForm();
            updateForm.Show();

        }

        private void searchBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            searchBy searchBy = new searchBy();
            searchBy.Show();
        }
    }
}
