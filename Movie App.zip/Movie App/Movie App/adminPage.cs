﻿using System;
using System.Windows.Forms;

namespace Movie_App
{
    public partial class adminPage : Form
    {
        public adminPage()
        {
            InitializeComponent();
        }

        private void backBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            LogInForm logInForm = new LogInForm();
            logInForm.Show();
        }

        private void searchBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            Newfilm newFilm=new Newfilm();
            newFilm.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
            deleteupdateForm deleteupdate = new deleteupdateForm();
            deleteupdate.Show();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
            UpdatePage updatePage=new UpdatePage();
            updatePage.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            deleteUsers deleteUsers=new deleteUsers();
            deleteUsers.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Hide();
            addActor addActor=new addActor();
            addActor.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            this.Hide();
            Report_Viewer reportPage=new Report_Viewer();
            reportPage.Show();
        }
    }
}
