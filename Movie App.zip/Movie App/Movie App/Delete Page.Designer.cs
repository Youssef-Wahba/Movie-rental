﻿namespace Movie_App
{
    partial class deleteupdateForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.Label delete;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(deleteupdateForm));
            this.title = new System.Windows.Forms.Label();
            this.backBtn = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.movieId = new System.Windows.Forms.Label();
            this.deleteFilm = new System.Windows.Forms.Button();
            delete = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // title
            // 
            this.title.AutoSize = true;
            this.title.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.title.Cursor = System.Windows.Forms.Cursors.Default;
            this.title.Font = new System.Drawing.Font("Showcard Gothic", 10.2F);
            this.title.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.title.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.title.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.title.Location = new System.Drawing.Point(12, 9);
            this.title.Name = "title";
            this.title.Size = new System.Drawing.Size(127, 21);
            this.title.TabIndex = 12;
            this.title.Text = "Movie Rental";
            // 
            // backBtn
            // 
            this.backBtn.BackColor = System.Drawing.Color.Black;
            this.backBtn.Font = new System.Drawing.Font("Showcard Gothic", 7.8F, System.Drawing.FontStyle.Italic);
            this.backBtn.ForeColor = System.Drawing.Color.White;
            this.backBtn.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.backBtn.Location = new System.Drawing.Point(802, 461);
            this.backBtn.Name = "backBtn";
            this.backBtn.Size = new System.Drawing.Size(73, 44);
            this.backBtn.TabIndex = 13;
            this.backBtn.Text = "back";
            this.backBtn.UseVisualStyleBackColor = false;
            this.backBtn.Click += new System.EventHandler(this.backBtn_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(16, 88);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(846, 150);
            this.dataGridView1.TabIndex = 14;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(261, 274);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(366, 22);
            this.textBox1.TabIndex = 18;
            // 
            // movieId
            // 
            this.movieId.AutoSize = true;
            this.movieId.Font = new System.Drawing.Font("Showcard Gothic", 10.2F);
            this.movieId.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.movieId.Location = new System.Drawing.Point(110, 275);
            this.movieId.Name = "movieId";
            this.movieId.Size = new System.Drawing.Size(85, 21);
            this.movieId.TabIndex = 25;
            this.movieId.Text = "Movie ID";
            // 
            // deleteFilm
            // 
            this.deleteFilm.BackColor = System.Drawing.Color.Black;
            this.deleteFilm.Font = new System.Drawing.Font("Showcard Gothic", 7.8F, System.Drawing.FontStyle.Italic);
            this.deleteFilm.ForeColor = System.Drawing.Color.White;
            this.deleteFilm.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.deleteFilm.Location = new System.Drawing.Point(374, 351);
            this.deleteFilm.Name = "deleteFilm";
            this.deleteFilm.Size = new System.Drawing.Size(122, 44);
            this.deleteFilm.TabIndex = 31;
            this.deleteFilm.Text = "Delete";
            this.deleteFilm.UseVisualStyleBackColor = false;
            this.deleteFilm.Click += new System.EventHandler(this.deleteFilm_Click);
            // 
            // delete
            // 
            delete.AutoSize = true;
            delete.Font = new System.Drawing.Font("Showcard Gothic", 28.2F, System.Drawing.FontStyle.Bold);
            delete.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            delete.Location = new System.Drawing.Point(345, 9);
            delete.Name = "delete";
            delete.Size = new System.Drawing.Size(197, 59);
            delete.TabIndex = 32;
            delete.Text = "Delete";
            // 
            // deleteupdateForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(887, 517);
            this.Controls.Add(delete);
            this.Controls.Add(this.deleteFilm);
            this.Controls.Add(this.movieId);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.backBtn);
            this.Controls.Add(this.title);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "deleteupdateForm";
            this.Text = "Delete / Updates";
            this.Load += new System.EventHandler(this.deleteupdateForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label title;
        private System.Windows.Forms.Button backBtn;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label movieId;
        private System.Windows.Forms.Button deleteFilm;
    }
}