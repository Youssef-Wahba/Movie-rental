﻿using System;
using System.Data;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Movie_App
{
    public partial class searchBy : Form
    {
        public searchBy()
        {
            InitializeComponent();
        }

        private void searchByNameBtn_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=JOE-LABTOP;Initial Catalog=MovieAppDB;Integrated Security=True");
            con.Open();
            SqlDataAdapter dataAdapter = new SqlDataAdapter("SELECT TITLE,DESCRIPTION,LANGUAGE,RATING,RELEASEDATE,PRICE FROM MOVIE WHERE TITLE = '" + searchCriteia.Text + "'ORDER BY TITLE ", con);
            DataTable dataTable = new DataTable();
            dataAdapter.Fill(dataTable);
            if (dataTable == null || dataTable.Rows.Count < 1)
                MessageBox.Show("Film With Name '" + searchCriteia.Text + "' Not Found");
            else
            {
                fimNameDataGridView.DataSource = dataTable;
                fimNameDataGridView.AutoResizeColumns();
            }
            con.Close();
        }

        private void signupFirstName_TextChanged(object sender, EventArgs e)
        {

        }

        private void backBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            userPage userPage=new userPage();
            userPage.Show();
        }

        private void searchByLangugeBtn_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=JOE-LABTOP;Initial Catalog=MovieAppDB;Integrated Security=True");
            con.Open();
            SqlDataAdapter dataAdapter = new SqlDataAdapter("SELECT TITLE,DESCRIPTION,LANGUAGE,RATING,RELEASEDATE,PRICE FROM MOVIE WHERE LANGUAGE = '" + searchCriteia.Text + "'ORDER BY LANGUAGE ", con);
            DataTable dataTable = new DataTable();
            dataAdapter.Fill(dataTable);
            if (dataTable == null || dataTable.Rows.Count < 1)
                MessageBox.Show("Film With Language '" + searchCriteia.Text + "' Not Found");
            else
            {
                fimNameDataGridView.DataSource = dataTable;
                fimNameDataGridView.AutoResizeColumns();
            }
            con.Close();

        }

        private void searchByRatingBtn_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=JOE-LABTOP;Initial Catalog=MovieAppDB;Integrated Security=True");
            con.Open();
            SqlDataAdapter dataAdapter = new SqlDataAdapter("SELECT TITLE,DESCRIPTION,LANGUAGE,RATING,RELEASEDATE,PRICE FROM MOVIE WHERE RATING = '" + searchCriteia.Text + "'ORDER BY RATING DESC ", con);
            DataTable dataTable = new DataTable();
            dataAdapter.Fill(dataTable);
            if (dataTable == null || dataTable.Rows.Count < 1)
                MessageBox.Show("Film With Rating '" + searchCriteia.Text + "' Not Found");
            else
            {
                fimNameDataGridView.DataSource = dataTable;
                fimNameDataGridView.AutoResizeColumns();
            }
            con.Close();
        }
    }
}
