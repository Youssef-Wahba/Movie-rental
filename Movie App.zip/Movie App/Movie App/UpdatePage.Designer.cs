﻿namespace Movie_App
{
    partial class UpdatePage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.Label login;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UpdatePage));
            this.backBtn = new System.Windows.Forms.Button();
            this.title = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.updateFilm = new System.Windows.Forms.Button();
            this.filmPrice = new System.Windows.Forms.Label();
            this.filmReleaseDate = new System.Windows.Forms.Label();
            this.filmRating = new System.Windows.Forms.Label();
            this.filmLang = new System.Windows.Forms.Label();
            this.filmDesc = new System.Windows.Forms.Label();
            this.adminId = new System.Windows.Forms.Label();
            this.filmTitle = new System.Windows.Forms.Label();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            login = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // backBtn
            // 
            this.backBtn.BackColor = System.Drawing.Color.Black;
            this.backBtn.Font = new System.Drawing.Font("Showcard Gothic", 7.8F, System.Drawing.FontStyle.Italic);
            this.backBtn.ForeColor = System.Drawing.Color.White;
            this.backBtn.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.backBtn.Location = new System.Drawing.Point(1094, 477);
            this.backBtn.Name = "backBtn";
            this.backBtn.Size = new System.Drawing.Size(73, 44);
            this.backBtn.TabIndex = 13;
            this.backBtn.Text = "back";
            this.backBtn.UseVisualStyleBackColor = false;
            this.backBtn.Click += new System.EventHandler(this.backBtn_Click);
            // 
            // title
            // 
            this.title.AutoSize = true;
            this.title.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.title.Cursor = System.Windows.Forms.Cursors.Default;
            this.title.Font = new System.Drawing.Font("Showcard Gothic", 10.2F);
            this.title.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.title.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.title.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.title.Location = new System.Drawing.Point(12, 9);
            this.title.Name = "title";
            this.title.Size = new System.Drawing.Size(127, 21);
            this.title.TabIndex = 14;
            this.title.Text = "Movie Rental";
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(152, 30);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(846, 150);
            this.dataGridView1.TabIndex = 15;
            // 
            // updateFilm
            // 
            this.updateFilm.BackColor = System.Drawing.Color.Black;
            this.updateFilm.Font = new System.Drawing.Font("Showcard Gothic", 7.8F, System.Drawing.FontStyle.Italic);
            this.updateFilm.ForeColor = System.Drawing.Color.White;
            this.updateFilm.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.updateFilm.Location = new System.Drawing.Point(806, 331);
            this.updateFilm.Name = "updateFilm";
            this.updateFilm.Size = new System.Drawing.Size(219, 44);
            this.updateFilm.TabIndex = 45;
            this.updateFilm.Text = "Update";
            this.updateFilm.UseVisualStyleBackColor = false;
            this.updateFilm.Click += new System.EventHandler(this.updateFilm_Click);
            // 
            // filmPrice
            // 
            this.filmPrice.AutoSize = true;
            this.filmPrice.Font = new System.Drawing.Font("Showcard Gothic", 10.2F);
            this.filmPrice.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.filmPrice.Location = new System.Drawing.Point(142, 487);
            this.filmPrice.Name = "filmPrice";
            this.filmPrice.Size = new System.Drawing.Size(58, 21);
            this.filmPrice.TabIndex = 44;
            this.filmPrice.Text = "Price";
            // 
            // filmReleaseDate
            // 
            this.filmReleaseDate.AutoSize = true;
            this.filmReleaseDate.Font = new System.Drawing.Font("Showcard Gothic", 10.2F);
            this.filmReleaseDate.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.filmReleaseDate.Location = new System.Drawing.Point(121, 437);
            this.filmReleaseDate.Name = "filmReleaseDate";
            this.filmReleaseDate.Size = new System.Drawing.Size(190, 21);
            this.filmReleaseDate.TabIndex = 43;
            this.filmReleaseDate.Text = "ReleaseDate (y-m-d)";
            // 
            // filmRating
            // 
            this.filmRating.AutoSize = true;
            this.filmRating.Font = new System.Drawing.Font("Showcard Gothic", 10.2F);
            this.filmRating.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.filmRating.Location = new System.Drawing.Point(142, 386);
            this.filmRating.Name = "filmRating";
            this.filmRating.Size = new System.Drawing.Size(71, 21);
            this.filmRating.TabIndex = 42;
            this.filmRating.Text = "Rating";
            // 
            // filmLang
            // 
            this.filmLang.AutoSize = true;
            this.filmLang.Font = new System.Drawing.Font("Showcard Gothic", 10.2F);
            this.filmLang.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.filmLang.Location = new System.Drawing.Point(147, 341);
            this.filmLang.Name = "filmLang";
            this.filmLang.Size = new System.Drawing.Size(52, 21);
            this.filmLang.TabIndex = 41;
            this.filmLang.Text = "lang";
            // 
            // filmDesc
            // 
            this.filmDesc.AutoSize = true;
            this.filmDesc.Font = new System.Drawing.Font("Showcard Gothic", 10.2F);
            this.filmDesc.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.filmDesc.Location = new System.Drawing.Point(148, 291);
            this.filmDesc.Name = "filmDesc";
            this.filmDesc.Size = new System.Drawing.Size(51, 21);
            this.filmDesc.TabIndex = 40;
            this.filmDesc.Text = "desc";
            // 
            // adminId
            // 
            this.adminId.AutoSize = true;
            this.adminId.Font = new System.Drawing.Font("Showcard Gothic", 10.2F);
            this.adminId.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.adminId.Location = new System.Drawing.Point(148, 203);
            this.adminId.Name = "adminId";
            this.adminId.Size = new System.Drawing.Size(87, 21);
            this.adminId.TabIndex = 38;
            this.adminId.Text = "Admin ID";
            // 
            // filmTitle
            // 
            this.filmTitle.AutoSize = true;
            this.filmTitle.Font = new System.Drawing.Font("Showcard Gothic", 10.2F);
            this.filmTitle.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.filmTitle.Location = new System.Drawing.Point(148, 246);
            this.filmTitle.Name = "filmTitle";
            this.filmTitle.Size = new System.Drawing.Size(54, 21);
            this.filmTitle.TabIndex = 39;
            this.filmTitle.Text = "Title";
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(341, 486);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(366, 22);
            this.textBox7.TabIndex = 37;
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(341, 436);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(366, 22);
            this.textBox6.TabIndex = 36;
            this.textBox6.TextChanged += new System.EventHandler(this.textBox6_TextChanged);
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(341, 385);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(366, 22);
            this.textBox5.TabIndex = 35;
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(341, 343);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(366, 22);
            this.textBox4.TabIndex = 34;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(341, 293);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(366, 22);
            this.textBox3.TabIndex = 33;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(341, 248);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(366, 22);
            this.textBox2.TabIndex = 32;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(341, 202);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(366, 22);
            this.textBox1.TabIndex = 31;
            // 
            // login
            // 
            login.AutoSize = true;
            login.Font = new System.Drawing.Font("Showcard Gothic", 22.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            login.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            login.Location = new System.Drawing.Point(1004, 66);
            login.Name = "login";
            login.Size = new System.Drawing.Size(170, 46);
            login.TabIndex = 46;
            login.Text = "Update";
            // 
            // textBox8
            // 
            this.textBox8.Location = new System.Drawing.Point(808, 202);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(366, 22);
            this.textBox8.TabIndex = 47;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Showcard Gothic", 10.2F);
            this.label1.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.label1.Location = new System.Drawing.Point(717, 203);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(85, 21);
            this.label1.TabIndex = 48;
            this.label1.Text = "Movie ID";
            // 
            // UpdatePage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1179, 531);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBox8);
            this.Controls.Add(login);
            this.Controls.Add(this.updateFilm);
            this.Controls.Add(this.filmPrice);
            this.Controls.Add(this.filmReleaseDate);
            this.Controls.Add(this.filmRating);
            this.Controls.Add(this.filmLang);
            this.Controls.Add(this.filmDesc);
            this.Controls.Add(this.adminId);
            this.Controls.Add(this.filmTitle);
            this.Controls.Add(this.textBox7);
            this.Controls.Add(this.textBox6);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.title);
            this.Controls.Add(this.backBtn);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "UpdatePage";
            this.Text = "Update Form";
            this.Load += new System.EventHandler(this.UpdatePage_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button backBtn;
        private System.Windows.Forms.Label title;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button updateFilm;
        private System.Windows.Forms.Label filmPrice;
        private System.Windows.Forms.Label filmReleaseDate;
        private System.Windows.Forms.Label filmRating;
        private System.Windows.Forms.Label filmLang;
        private System.Windows.Forms.Label filmDesc;
        private System.Windows.Forms.Label adminId;
        private System.Windows.Forms.Label filmTitle;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.Label label1;
    }
}