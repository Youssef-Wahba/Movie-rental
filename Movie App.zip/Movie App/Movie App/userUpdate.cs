﻿using System;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Movie_App
{
    public partial class updateForm : Form
    {
        public updateForm()
        {
            InitializeComponent();
        }

        private void updateBtn_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection("Data Source=JOE-LABTOP;Initial Catalog=MovieAppDB;Integrated Security=True");
            SqlCommand comnew = new SqlCommand("UPDATE CUSTOMER SET FIRSTNAME = '"+firstNameTextBox.Text+ "', LASTNAME = '" + lastNameTextBox.Text + "', ADDRESS = '" + addressTextBox.Text + "', PHONE = '" + phoneNumberTextBox.Text + "', EMAIL = '" + emailTextBox.Text + "', PASSWORD = '" + passTextBox.Text + "' WHERE CID = " + idTextBox.Text + "; ", con);
            con.Open();
            comnew.ExecuteNonQuery();
            MessageBox.Show("User Data Updated Successfully :)");
            con.Close();
        }

        private void backBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
            userPage userPage=new userPage();
            userPage.Show();
        }
    }
}
