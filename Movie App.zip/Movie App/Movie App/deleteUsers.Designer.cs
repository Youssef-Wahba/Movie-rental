﻿namespace Movie_App
{
    partial class deleteUsers
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.Label delete;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(deleteUsers));
            this.title = new System.Windows.Forms.Label();
            this.backBtn = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.deleteFilm = new System.Windows.Forms.Button();
            this.userId = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            delete = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // title
            // 
            this.title.AutoSize = true;
            this.title.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.title.Cursor = System.Windows.Forms.Cursors.Default;
            this.title.Font = new System.Drawing.Font("Showcard Gothic", 10.2F);
            this.title.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.title.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.title.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.title.Location = new System.Drawing.Point(12, 9);
            this.title.Name = "title";
            this.title.Size = new System.Drawing.Size(127, 21);
            this.title.TabIndex = 13;
            this.title.Text = "Movie Rental";
            // 
            // backBtn
            // 
            this.backBtn.BackColor = System.Drawing.Color.Black;
            this.backBtn.Font = new System.Drawing.Font("Showcard Gothic", 7.8F, System.Drawing.FontStyle.Italic);
            this.backBtn.ForeColor = System.Drawing.Color.White;
            this.backBtn.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.backBtn.Location = new System.Drawing.Point(715, 394);
            this.backBtn.Name = "backBtn";
            this.backBtn.Size = new System.Drawing.Size(73, 44);
            this.backBtn.TabIndex = 14;
            this.backBtn.Text = "back";
            this.backBtn.UseVisualStyleBackColor = false;
            this.backBtn.Click += new System.EventHandler(this.backBtn_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(16, 129);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(772, 150);
            this.dataGridView1.TabIndex = 15;
            // 
            // delete
            // 
            delete.AutoSize = true;
            delete.Font = new System.Drawing.Font("Showcard Gothic", 28.2F, System.Drawing.FontStyle.Bold);
            delete.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            delete.Location = new System.Drawing.Point(213, 34);
            delete.Name = "delete";
            delete.Size = new System.Drawing.Size(351, 59);
            delete.TabIndex = 33;
            delete.Text = "Delete Users";
            // 
            // deleteFilm
            // 
            this.deleteFilm.BackColor = System.Drawing.Color.Black;
            this.deleteFilm.Font = new System.Drawing.Font("Showcard Gothic", 7.8F, System.Drawing.FontStyle.Italic);
            this.deleteFilm.ForeColor = System.Drawing.Color.White;
            this.deleteFilm.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.deleteFilm.Location = new System.Drawing.Point(357, 374);
            this.deleteFilm.Name = "deleteFilm";
            this.deleteFilm.Size = new System.Drawing.Size(122, 44);
            this.deleteFilm.TabIndex = 36;
            this.deleteFilm.Text = "Delete";
            this.deleteFilm.UseVisualStyleBackColor = false;
            this.deleteFilm.Click += new System.EventHandler(this.deleteFilm_Click);
            // 
            // userId
            // 
            this.userId.AutoSize = true;
            this.userId.Font = new System.Drawing.Font("Showcard Gothic", 10.2F);
            this.userId.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.userId.Location = new System.Drawing.Point(86, 318);
            this.userId.Name = "userId";
            this.userId.Size = new System.Drawing.Size(74, 21);
            this.userId.TabIndex = 35;
            this.userId.Text = "User Id";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(237, 317);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(366, 22);
            this.textBox1.TabIndex = 34;
            // 
            // deleteUsers
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.deleteFilm);
            this.Controls.Add(this.userId);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(delete);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.backBtn);
            this.Controls.Add(this.title);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "deleteUsers";
            this.Text = "Delete Users";
            this.Load += new System.EventHandler(this.deleteUsers_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label title;
        private System.Windows.Forms.Button backBtn;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button deleteFilm;
        private System.Windows.Forms.Label userId;
        private System.Windows.Forms.TextBox textBox1;
    }
}